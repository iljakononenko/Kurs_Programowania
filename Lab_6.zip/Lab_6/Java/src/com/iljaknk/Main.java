package com.iljaknk;

/**
 * Klasa glowna main, uruchamiajca program uzytkownika
 */

public class Main {

    /**
     * Metoda glowna klasy glownej Main
     * @param args
     */

    public static void main(String[] args)
    {
        BST<Integer> new_tree = new BST<>();

        my_Frame frame = new my_Frame();
    }
}
